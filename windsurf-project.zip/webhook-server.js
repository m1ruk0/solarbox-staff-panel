require('dotenv').config();
const express = require('express');
const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

function createWebhookServer(client) {
  const app = express();
  app.use(express.json());

  // Endpoint для получения данных из Google Forms
  app.post('/webhook/application', async (req, res) => {
    try {
      const data = req.body;
      
      // Получаем канал для отправки заявки
      const channelId = process.env.APPLICATION_CHANNEL_ID;
      const channel = await client.channels.fetch(channelId);

      if (!channel) {
        return res.status(404).json({ error: 'Channel not found' });
      }

      // Извлекаем Discord ник и тип заявки из данных
      let discordUsername = '';
      let applicationType = '';
      const fields = data.fields || [];
      
      console.log('📋 Полученные поля из формы:');
      fields.forEach((field, index) => {
        console.log(`   ${index + 1}. "${field.name}" = "${field.value}"`);
      });
      
      for (const field of fields) {
        const fieldNameLower = field.name.toLowerCase();
        const fieldValueLower = field.value.toLowerCase();
        
        // Ищем поле с Discord
        if (fieldNameLower.includes('дискорд') || fieldNameLower.includes('discord')) {
          discordUsername = field.value;
          console.log(`✅ Найдено поле с Discord: "${field.name}" = "${discordUsername}"`);
        }
        
        // Определяем тип заявки
        if (fieldNameLower.includes('должность') || fieldNameLower.includes('роль') || 
            fieldValueLower.includes('хелпер') || fieldValueLower.includes('медия')) {
          if (fieldValueLower.includes('хелпер')) {
            applicationType = 'хелпер';
          } else if (fieldValueLower.includes('медия')) {
            applicationType = 'медия';
          }
          console.log(`✅ Тип заявки: ${applicationType}`);
        }
      }
      
      if (!discordUsername) {
        console.log('⚠️ Поле с Discord ником не найдено!');
      }
      
      if (!applicationType) {
        applicationType = 'хелпер'; // По умолчанию
        console.log('⚠️ Тип заявки не определен, используется: хелпер');
      }

      // Создаем embed
      const embed = new EmbedBuilder()
        .setColor(data.color || 0x00ff00)
        .setTimestamp();

      // Добавляем title если есть
      if (data.title) {
        embed.setTitle(data.title);
      }

      // Добавляем description если есть
      if (data.description) {
        embed.setDescription(data.description);
      }

      // Добавляем поля
      if (fields.length > 0) {
        fields.forEach(field => {
          embed.addFields({
            name: field.name,
            value: field.value,
            inline: field.inline || false
          });
        });
      }

      if (data.footer) {
        embed.setFooter({ text: data.footer });
      }

      // Создаем кнопки с типом заявки
      const row = new ActionRowBuilder()
        .addComponents(
          new ButtonBuilder()
            .setCustomId(`accept_${applicationType}_${discordUsername}`)
            .setLabel('✅ Принять')
            .setStyle(ButtonStyle.Success),
          new ButtonBuilder()
            .setCustomId(`reject_${applicationType}_${discordUsername}`)
            .setLabel('❌ Отказать')
            .setStyle(ButtonStyle.Danger)
        );

      // Отправляем сообщение с кнопками
      const message = await channel.send({
        content: data.content || '',
        embeds: [embed],
        components: [row]
      });

      res.status(200).json({ success: true, messageId: message.id });
    } catch (error) {
      console.error('Ошибка при обработке webhook:', error);
      res.status(500).json({ error: error.message });
    }
  });

  // Запуск сервера
  const PORT = process.env.PORT || 3000;
  app.listen(PORT, () => {
    console.log(`🌐 Webhook сервер запущен на порту ${PORT}`);
    console.log(`📡 URL для webhook: http://localhost:${PORT}/webhook/application`);
  });

  return app;
}

module.exports = { createWebhookServer };
